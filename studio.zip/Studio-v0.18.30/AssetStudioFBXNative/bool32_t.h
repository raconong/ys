#pragma once

#include <cstdint>

typedef uint32_t bool32_t;
