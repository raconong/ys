﻿namespace AssetStudio
{
    public class AssetEntry
    {
        public string Name;
        public string Container;
        public string Source;
        public long PathID;
        public ClassIDType Type;
    }
}
