﻿namespace AssetStudio.FbxInterop
{
    internal static class FbxDll
    {

        internal const string DllName = "AssetStudioFBXNative";
        internal const string FbxsdkDllName = "libfbxsdk";

    }
}
