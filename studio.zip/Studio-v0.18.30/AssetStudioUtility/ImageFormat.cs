﻿namespace AssetStudio
{
    public enum ImageFormat
    {
        Jpeg,
        Png,
        Bmp,
        Tga
    }
}
